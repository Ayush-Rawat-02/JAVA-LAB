/*
Hello.java
my first program in java	
4/03/2022
*/

class Hello
{
	public static void main(String args[])
	{
		System.out.println("Hello World");
	}

}
