package mypack;
import java.util.Scanner;
class CountWords
{
	public static void numberOfChar(){
		String s;
		s=(new Scanner(System.in)).nextLine();
		int sz=s.length();
		int it=0;
		for(int i=0;i<sz;i++)
			if(s.charAt(i)!=' ')	it++;
		System.out.println("Number of characters : "+it);
	}
};

class Duplicate{
	public static void duplicates(){
		String s=(new Scanner(System.in)).nextLine();
		int n=s.length();
		System.out.println("The duplicate characters are : ");
		//s.sort();
		for(int i=0;i<n;i++){
			for(int j=i+1;j<n;j++)
				if(s.charAt(i)==s.charAt(j)){
					System.out.print(s.charAt(i)+" ");
				}
		}
	}
};

class Fibonacci{
	public static void fibonacci(){
		int a=0,b=1;
		int n;
		System.out.print("Enter the number of terms in the series : ");
		n=(new Scanner(System.in)).nextInt();
		System.out.print(a+" ");
		if(n==1)return;
		System.out.print(b+" ");
		for(int i=3;i<=n;i++){
			System.out.print(a+b+" ");
			int tmp=a+b;
			a=b;
			b=tmp;
		}
	}
}

class Palindrome{
	public static void palindrome(){
		String s=(new Scanner(System.in)).nextLine();
		int n=s.length()-1;
		for(int i=0;i<=n/2;i++)
			if(s.charAt(i)!=s.charAt(n-i)){
				System.out.println("Not Palindrome ! ");
				return;
			}
		System.out.println("Palindrome");
	}
}

class SecondHighest{
	public static void secondLargest(){
		int n;
		System.out.print("Enter the number of elements in the array : ");
		n=(new Scanner(System.in)).nextInt();
		int arr[]=new int[100];
		for(int i=0;i<n;i++)	arr[i]=(new Scanner(System.in)).nextInt();
		//sorting the array
		for(int i=0;i<n-1;i++){
			int min=i;
			for(int j=i+1;j<n;j++){
				if(arr[min]>arr[j])	min=j;
			}
			int tmp=arr[i];
			arr[i]=arr[min];
			arr[min]=tmp;
		}
		System.out.println("Second largest element in the array is : "+arr[n-2]);
	}
}

class Main{
	public static void main(String args[]){	
		
	}
}

