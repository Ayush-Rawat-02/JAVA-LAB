/* 
Demonstration of taking input from commandline argument
This program takes input from command line and displays the data entered by the user
The data is : Name,course,rollno and Semester.
*/
class inputFromCommandLine
{
	public static void main(String args[])
	{
		System.out.println("Name : "+args[0]);
		System.out.println("Course : "+args[1]);
		System.out.println("Rollno : "+args[2]);
		System.out.println("Semester : "+args[3]);
	}
};
