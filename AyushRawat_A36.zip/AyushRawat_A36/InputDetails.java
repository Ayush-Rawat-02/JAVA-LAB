/* WAP in java to take input the detail sof studene(name , rollno , mobile number , 
Aadhar number , date of birth) using Scanner class
*/
import java.util.Scanner;

class InputDetails{
	public static void main(String args[]){
		
		//Scanner ip = new Scanner(System.in);

		System.out.println("Please enter your details : ");
		System.out.print("Name : ");
		String name = (new Scanner(System.in)).nextLine();

		System.out.print("Age : ");
		int age = (new Scanner(System.in)).nextInt();

		//Scanner db = new Scanner(System.in);
		System.out.print("DOB : ");
		String dob = (new Scanner(System.in)).nextLine();
		
		//Scanner mn = new Scanner(System.in);
		System.out.print("Mobile number : ");
		String mob = (new Scanner(System.in)).nextLine();

		//Scanner adn = new Scanner(System.in);		
		System.out.print("Aadhar number : ");
		String aadhar = (new Scanner(System.in)).nextLine();

		System.out.println("The detailes entered by you are : ");
		System.out.println("Name :"+name+"\nAge:"+age+"\nDOB : "+dob+"\nMobile number : "+mob+"\nAadhar number : "+aadhar);
		
	}	
};
