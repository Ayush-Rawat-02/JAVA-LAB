/*
Write a program using scanner class to input three sides of a triangle and display its area
*/

import java.util.Scanner;
import java.lang.Math;

class AreaTriangle{
	public static void main(String args[]){
		int a,b,c;
		System.out.println("Enter the sides of the triangle one by one : ");
		a=(new Scanner(System.in)).nextInt();
		b=(new Scanner(System.in)).nextInt();
		c=(new Scanner(System.in)).nextInt();
		if(a+b<c||b+c<a||a+c<b){
			System.out.println("Not a valid triangle");
			return;		
		}
		double s=(a+b+c)/2.00;
		double tmp=s*(s-a)*(s-b)*(s-c);
		double area=Math.sqrt(tmp);
		System.out.println("The area of the triangle is  : "+area);
	}
}

