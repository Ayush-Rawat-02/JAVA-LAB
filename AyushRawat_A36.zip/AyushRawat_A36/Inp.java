import java.util.Scanner;
class Inp{
	public static void main(String args[]){
		Scanner ob = new Scanner(System.in);
		int a = ob.nextInt();
		System.out.println("You Entered : "+a);
	}
};
